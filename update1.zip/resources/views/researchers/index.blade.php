@extends('layout')

@section('content')
{!! $grid !!}
@endsection