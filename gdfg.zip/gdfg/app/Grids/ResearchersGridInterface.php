<?php

namespace App\Grids;

use Leantony\Grid\GridInterface;

interface ResearchersGridInterface extends GridInterface
{
    //
}