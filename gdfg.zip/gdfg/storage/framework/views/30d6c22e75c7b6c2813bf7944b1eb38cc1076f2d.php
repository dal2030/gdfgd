</div>

<!-- Modal footer -->
<div class="modal-footer">
    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i>&nbsp;<?php echo e('Close'); ?>

    </button>
    <button type="submit" class="btn btn-success"><i class="fa fa-floppy-o"></i>&nbsp;<?php echo e('Save'); ?></button>
</div>
</form>