<div class="modal fade" id="bootstrap_modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- the modal content will be injected here -->
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->