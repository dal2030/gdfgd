<!-- Modal Header -->
<div class="modal-header">
    <h4 class="modal-title"><?php echo e(ucwords($modal['action'] . ' '. class_basename($modal['model']))); ?></h4>
    <button type="button" class="close" data-dismiss="modal">&times;</button>
</div>

<!-- Modal body -->
<form accept-charset="UTF-8" action="<?php echo e($modal['route']); ?>" id="modal_form"
      data-pjax-target="#<?php echo e($modal['pjaxContainer'] ?? null); ?>" method="POST">
    <div class="modal-body">
        <div id="modal-notification"></div>
        <?php if(isset($modal['method']) && $modal['method'] != 'post'): ?>
            <input type="hidden" name="_method" value="<?php echo e($modal['method']); ?>">
        <?php endif; ?>
<?php echo csrf_field(); ?>